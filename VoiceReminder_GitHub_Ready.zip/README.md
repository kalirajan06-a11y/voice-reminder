# Voice Reminder Android App (Screen-Off Voice & Text Reminder)

இந்த Android ஆப், நீங்கள் குறிப்பிட்ட நேரத்தில் Text மற்றும் Voice மூலமாக Reminder கொடுக்கும். **மொபைல் screen off-ல் இருந்தாலும் (Lock screen / Doze mode)** கூட இது சரியாக Voice மற்றும் Screen Alert கொடுக்கும் வகையில் வடிவமைக்கப்பட்டுள்ளது.

---

## 🔑 Screen Off-ல் Voice Reminder வேலை செய்யத் தேவையான 4 முக்கிய அம்சங்கள்:

1. **`AlarmManager.setExactAndAllowWhileIdle(RTC_WAKEUP, ...)`**:
   - மொபைல் தூக்கத்தில் (Doze Mode) இருந்தாலும் CPU-வை விழித்தெழ (Wake up) செய்ய `RTC_WAKEUP` பயன்படுகிறது.
2. **`PowerManager.PARTIAL_WAKE_LOCK`**:
   - Screen ஆஃப்-ல் இருக்கும்போது Android OS தூங்கச் செல்லாமல், TextToSpeech குரல் பேசி முடிக்கும் வரை CPU-வை ஆக்டிவாக வைத்திருக்க இது தேவை.
3. **`Foreground Service` with `AudioAttributes.USAGE_ALARM`**:
   - Background limitations-ஐத் தாண்டி Background-ல் TextToSpeech இயங்க Foreground Service உதவுகிறது.
   - `USAGE_ALARM` பயன்படுத்துவதால் மொபைல் Silent/Vibrate-ல் இருந்தாலும் Alarm சத்தத்தில் Reminder குரல் கேட்கும்!
4. **`setShowWhenLocked(true)` & `setTurnScreenOn(true)`**:
   - மொபைல் Screen ஆஃப்-ல் இருந்து Lock ஆகி இருந்தாலும், ஸ்கிரீனை On செய்து Full-Screen Reminder Window-வை காட்டும்.

---

## 🛠️ Android Studio-வில் Run செய்வது எப்படி?

1. இந்த `VoiceReminderApp` ஃபோல்டரை உங்கள் கணினியில் எக்ஸ்ட்ராக்ட் (Extract) செய்யவும்.
2. **Android Studio** திறந்து `File -> Open` கொடுத்து இந்த ஃபோல்டரைத் தேர்வு செய்யவும்.
3. Gradle Sync முடியும் வரை காத்திருக்கவும்.
4. உங்கள் Android Phone-ஐ USB Debugging மூலம் இணைத்து `Run` பட்டனை அழுத்தவும்.

---

## ⚙️ மொபைலில் கவனிக்க வேண்டிய முக்கியமான Settings (One-Time Setup):

1. **Battery Optimization**:
   - ஆப்பில் உள்ள **"Disable Battery Optimization"** பட்டனை கிளிக் செய்து "Don't Optimize" / "Unrestricted" என்று அமைக்கவும். (Xiaomi, Samsung, OnePlus, Vivo போன்ற போன்களில் இது மிக முக்கியம்).
2. **Alarms & Reminders Permission**:
   - Android 12, 13, 14-ல் `Settings -> Apps -> Special App Access -> Alarms & Reminders`-ல் அனுமதி கொடுக்கப்பட்டுள்ளதா என சரிபார்க்கவும்.
3. **Display over other apps / Show on Lock screen**:
   - Xiaomi (MIUI/HyperOS), Vivo, Oppo போன்ற மொபைல்களில் `Permissions -> Show on Lock Screen` மற்றும் `Display pop-up windows while running in background` இயக்கப்பட வேண்டும்.
