package com.example.voicereminder

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ReminderActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Wake screen up, turn on display and show over lock screen
        turnScreenOnAndShowWhenLocked()

        setContentView(R.layout.activity_reminder)

        val reminderText = intent.getStringExtra(AlarmReceiver.EXTRA_REMINDER_TEXT) ?: "Reminder Alert!"
        val tvMessage = findViewById<TextView>(R.id.tvReminderMessage)
        val btnDismiss = findViewById<Button>(R.id.btnDismiss)

        tvMessage.text = reminderText

        btnDismiss.setOnClickListener {
            // Stop foreground service if still playing
            val stopIntent = Intent(this, VoiceReminderService::class.java)
            stopService(stopIntent)
            finish()
        }
    }

    private fun turnScreenOnAndShowWhenLocked() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
    }
}
