package com.example.voicereminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_TRIGGER_REMINDER = "com.example.voicereminder.ACTION_TRIGGER_REMINDER"
        const val EXTRA_REMINDER_TEXT = "extra_reminder_text"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderText = intent.getStringExtra(EXTRA_REMINDER_TEXT) ?: "Reminder alert!"

        // Acquire a temporary partial wake lock to guarantee CPU stays active
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "VoiceReminder:AlarmReceiverWakeLock"
        )
        wakeLock.acquire(10 * 1000L /* 10 seconds timeout */)

        // Start Foreground Service to speak the reminder & display notification / lock-screen intent
        val serviceIntent = Intent(context, VoiceReminderService::class.java).apply {
            putExtra(EXTRA_REMINDER_TEXT, reminderText)
        }

        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
