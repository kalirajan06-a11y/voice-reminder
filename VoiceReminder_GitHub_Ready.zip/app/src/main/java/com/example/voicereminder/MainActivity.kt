package com.example.voicereminder

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var etReminderText: EditText
    private lateinit var tvSelectedTime: TextView
    private lateinit var btnPickDateTime: Button
    private lateinit var btnSetReminder: Button
    private lateinit var btnBatteryOpt: Button

    private val selectedCalendar = Calendar.getInstance()
    private var isTimeSelected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etReminderText = findViewById(R.id.etReminderText)
        tvSelectedTime = findViewById(R.id.tvSelectedTime)
        btnPickDateTime = findViewById(R.id.btnPickDateTime)
        btnSetReminder = findViewById(R.id.btnSetReminder)
        btnBatteryOpt = findViewById(R.id.btnBatteryOpt)

        checkAndRequestPermissions()

        btnPickDateTime.setOnClickListener {
            showDatePicker()
        }

        btnSetReminder.setOnClickListener {
            val text = etReminderText.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, "Reminder text ஐ உள்ளிடவும்!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!isTimeSelected || selectedCalendar.timeInMillis <= System.currentTimeMillis()) {
                Toast.makeText(this, "எதிர்கால நேரத்தை (Future time) தேர்வு செய்யவும்!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            scheduleVoiceReminder(text, selectedCalendar.timeInMillis)
        }

        btnBatteryOpt.setOnClickListener {
            requestIgnoreBatteryOptimization()
        }
    }

    private fun showDatePicker() {
        val now = Calendar.getInstance()
        val datePicker = DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                selectedCalendar.set(Calendar.YEAR, year)
                selectedCalendar.set(Calendar.MONTH, month)
                selectedCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                showTimePicker()
            },
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH),
            now.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.datePicker.minDate = System.currentTimeMillis()
        datePicker.show()
    }

    private fun showTimePicker() {
        val now = Calendar.getInstance()
        val timePicker = TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                selectedCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                selectedCalendar.set(Calendar.MINUTE, minute)
                selectedCalendar.set(Calendar.SECOND, 0)
                selectedCalendar.set(Calendar.MILLISECOND, 0)

                isTimeSelected = true
                val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                tvSelectedTime.text = "தேர்வு செய்த நேரம்: " + sdf.format(selectedCalendar.time)
            },
            now.get(Calendar.HOUR_OF_DAY),
            now.get(Calendar.MINUTE),
            false
        )
        timePicker.show()
    }

    private fun scheduleVoiceReminder(reminderText: String, triggerTimeMillis: Long) {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // Android 12+ check for exact alarm capability
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!alarmManager.canScheduleExactAlarms()) {
                Toast.makeText(this, "Exact alarm அனுமதி தேவை. Settings-ல் இயக்கவும்.", Toast.LENGTH_LONG).show()
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
                return
            }
        }

        val intent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_REMINDER
            putExtra(AlarmReceiver.EXTRA_REMINDER_TEXT, reminderText)
        }

        val requestCode = (System.currentTimeMillis() % 100000).toInt()
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Wake up the phone from sleep/screen off using RTC_WAKEUP and setExactAndAllowWhileIdle
        try {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerTimeMillis,
                pendingIntent
            )
            val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
            Toast.makeText(
                this,
                "Reminder set செய்யப்பட்டது! நேரம்: ${sdf.format(selectedCalendar.time)}",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Alarm Permission Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
    }

    private fun requestIgnoreBatteryOptimization() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } else {
            Toast.makeText(this, "Battery Optimization ஏற்கனவே விலக்கப்பட்டுள்ளது!", Toast.LENGTH_SHORT).show()
        }
    }
}
