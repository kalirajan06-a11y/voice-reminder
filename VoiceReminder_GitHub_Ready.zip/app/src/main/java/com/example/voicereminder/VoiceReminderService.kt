package com.example.voicereminder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import java.util.Locale

class VoiceReminderService : Service(), TextToSpeech.OnInitListener {

    private var textToSpeech: TextToSpeech? = null
    private var reminderText: String = ""
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        private const val CHANNEL_ID = "voice_reminder_alarm_channel"
        private const val NOTIFICATION_ID = 1001
        private const val UTTERANCE_ID = "voice_reminder_utterance"
    }

    override fun onCreate() {
        super.onCreate()

        // Acquire WakeLock to keep CPU running while speaking even if screen is off
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "VoiceReminder:ServiceWakeLock"
        ).apply {
            acquire(3 * 60 * 1000L /* 3 minutes max safety timeout */)
        }

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        reminderText = intent?.getStringExtra(AlarmReceiver.EXTRA_REMINDER_TEXT)
            ?: "Reminder alert"

        val notification = buildForegroundNotification(reminderText)
        startForeground(NOTIFICATION_ID, notification)

        // Initialize TextToSpeech engine
        textToSpeech = TextToSpeech(this, this)

        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.let { tts ->
                // Try Indian English / Tamil / Default locale
                val result = tts.setLanguage(Locale("ta", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    // Fallback to default / English if Tamil TTS voice data is not installed
                    tts.language = Locale.getDefault()
                }

                // Important: Route voice audio to ALARM stream so it sounds aloud even if phone is on silent
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                tts.setAudioAttributes(audioAttributes)

                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(utteranceId: String?) {
                        // After speaking is completed, stop service and release wake lock
                        stopSelf()
                    }

                    override fun onError(utteranceId: String?) {
                        stopSelf()
                    }
                })

                // Format announcement text (Repeated 2 times so the user clearly hears it)
                val fullSpeech = "Reminder: $reminderText . Repeating: $reminderText"
                tts.speak(fullSpeech, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
            }
        } else {
            stopSelf()
        }
    }

    private fun buildForegroundNotification(message: String): Notification {
        // Intent to launch ReminderActivity over lock screen
        val fullScreenIntent = Intent(this, ReminderActivity::class.java).apply {
            putExtra(AlarmReceiver.EXTRA_REMINDER_TEXT, message)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            0,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Voice Reminder Alert")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreenPendingIntent, true) // Key for waking up screen
            .setAutoCancel(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Voice Reminder Alarm",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High priority alarms with voice speech"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setBypassDnd(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null

        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
